package main
import "fmt"

func main() {
	fmt.Print(1 + 1, " ", 5 - 3, " ", 5 * 5, " ", 13/3, " ", 13%3, "\n")
}
