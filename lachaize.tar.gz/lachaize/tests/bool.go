package main
import "fmt"

func main() {
	fmt.Print(1 <= 2, " ", (3 != 5) and (1 == 1), " ", (5 >= 0) or not (1 <= 100), "\n");
}
